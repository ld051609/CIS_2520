# CIS2520-F24-A2

## Student Information 
Name : Lan Dinh

Student Number : 1266220

## Assignment Overview
What is the assignment about?  
Explain the purpose of the program and what it accomplishes.
Question 1: The purpose of the car rental system program is to manage the inventory of cars in a rental company, allowing for various transactions to keep the lists of available, rented, and in-repair cars up to date.
Question 2: The purpose of the postfix expression evaluation program is to demonstrate the use of stacks in evaluating arithmetic expressions, providing a practical application of stack data structures.

Did you use any resources (for example book, notes etc) in this assignment?
Yes, I did used the helper function to get the node index from my CIS2500 assignment and the code in lecture slides to help with linked list for stack and queue implementations

## Implementation
Is the assignment complete? If not, mention what part of the assignment is missing or incomplete.
it may missing the memory leak checking part